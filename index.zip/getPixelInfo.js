export default function getPixelInfo(x, y, canvas) {
  if (x === Number) {
    const pixelData = canvas
      .getContext("2d", { willReadFrequently: true })
      .getImageData(x, y, 1, 1).data;
    const pixelColor = `rgb(${pixelData[0]},${pixelData[1]},${pixelData[2]},${pixelData[3]})`;
    return console.log(pixelData, pixelColor);
  }

  canvas.addEventListener("click", (e) => {
    const pixelData = canvas
      .getContext("2d", { willReadFrequently: true })
      .getImageData(e.pageX, e.pageY, 1, 1).data;
    const pixelColor = `rgb(${pixelData[0]},${pixelData[1]},${pixelData[2]},${pixelData[3]})`;
    console.log(pixelData, pixelColor);
  });
}
