import getPixelInfo from "./getPixelInfo.js";

const myImage = new Image();
myImage.src = "./dalle256.png";
myImage.style.width = "300px";
document.body.prepend(myImage);

// Function to get pixel information at a specific coordinate inside the canvas
const myCanvas = document.getElementById("canvas");
console.log(getPixelInfo);
console.log(getPixelInfo);
console.log(getPixelInfo(100, 100, myCanvas));

//  Function to set pixel colour
function setPixelColour() {
  const setPixel = canvas.getContext("2d").set;
}
